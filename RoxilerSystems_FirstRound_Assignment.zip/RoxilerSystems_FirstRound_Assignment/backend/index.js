require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const axios = require('axios');
const Transaction = require('./models/Transaction');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/transaction-dashboard')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

app.get('/api/initialize-database', async (req, res) => {
  try {
    const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    await Transaction.deleteMany({});
    await Transaction.insertMany(response.data);
    res.json({ message: 'Database initialized successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/transactions', async (req, res) => {
  try {
    const { month, search = '', page = 1, per_page = 10 } = req.query;
    const skip = (page - 1) * per_page;

    const query = {
      $expr: { 
        $eq: [{ $month: '$dateOfSale' }, parseInt(month)] 
      }
    };

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { price: isNaN(search) ? undefined : Number(search) }
      ].filter(Boolean);
    }

    const transactions = await Transaction.find(query)
      .skip(skip)
      .limit(parseInt(per_page));

    const total = await Transaction.countDocuments(query);

    res.json({
      transactions,
      total,
      page: parseInt(page),
      per_page: parseInt(per_page),
      total_pages: Math.ceil(total / per_page)
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/statistics', async (req, res) => {
  try {
    const { month } = req.query;
    const query = {
      $expr: { 
        $eq: [{ $month: '$dateOfSale' }, parseInt(month)] 
      }
    };

    const [totalSales, soldItems, notSoldItems] = await Promise.all([
      Transaction.aggregate([
        { $match: query },
        { $group: { _id: null, total: { $sum: '$price' } } }
      ]),
      Transaction.countDocuments({ ...query, sold: true }),
      Transaction.countDocuments({ ...query, sold: false })
    ]);

    res.json({
      totalSaleAmount: totalSales[0]?.total || 0,
      totalSoldItems: soldItems,
      totalNotSoldItems: notSoldItems
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/bar-chart', async (req, res) => {
  try {
    const { month } = req.query;
    const ranges = [
      { min: 0, max: 100 },
      { min: 101, max: 200 },
      { min: 201, max: 300 },
      { min: 301, max: 400 },
      { min: 401, max: 500 },
      { min: 501, max: 600 },
      { min: 601, max: 700 },
      { min: 701, max: 800 },
      { min: 801, max: 900 },
      { min: 901, max: Infinity }
    ];

    const result = await Promise.all(
      ranges.map(async ({ min, max }) => {
        const count = await Transaction.countDocuments({
          $expr: { 
            $eq: [{ $month: '$dateOfSale' }, parseInt(month)] 
          },
          price: { $gte: min, $lt: max === Infinity ? 1000000 : max }
        });
        return {
          range: `${min}-${max === Infinity ? 'above' : max}`,
          count
        };
      })
    );

    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/pie-chart', async (req, res) => {
  try {
    const { month } = req.query;
    const result = await Transaction.aggregate([
      {
        $match: {
          $expr: { 
            $eq: [{ $month: '$dateOfSale' }, parseInt(month)] 
          }
        }
      },
      {
        $group: {
          _id: '$category',
          count: { $sum: 1 }
        }
      }
    ]);

    res.json(result.map(item => ({
      category: item._id,
      count: item.count
    })));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/combined-data', async (req, res) => {
  try {
    const { month } = req.query;
    const [transactions, statistics, barChart, pieChart] = await Promise.all([
      axios.get(`http://localhost:3001/api/transactions?month=${month}`),
      axios.get(`http://localhost:3001/api/statistics?month=${month}`),
      axios.get(`http://localhost:3001/api/bar-chart?month=${month}`),
      axios.get(`http://localhost:3001/api/pie-chart?month=${month}`)
    ]);

    res.json({
      transactions: transactions.data,
      statistics: statistics.data,
      barChart: barChart.data,
      pieChart: pieChart.data
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});