const API_BASE_URL = 'http://localhost:3001/api';
let currentPage = 1;
let totalPages = 1;

// Initialize charts
let barChart, pieChart;

async function fetchData() {
    const month = document.getElementById('monthSelect').value;
    const search = document.getElementById('searchInput').value;
    
    try {
        const response = await fetch(`${API_BASE_URL}/combined-data?month=${month}&search=${search}&page=${currentPage}`);
        const data = await response.json();
        
        updateStatistics(data.statistics);
        updateTransactionsTable(data.transactions);
        updateCharts(data.barChart, data.pieChart);
        
        totalPages = data.transactions.total_pages;
        updatePaginationControls();
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

function updateStatistics(statistics) {
    document.getElementById('totalSale').textContent = `$${statistics.totalSaleAmount.toFixed(2)}`;
    document.getElementById('soldItems').textContent = statistics.totalSoldItems;
    document.getElementById('notSoldItems').textContent = statistics.totalNotSoldItems;
}

function updateTransactionsTable(transactionData) {
    const tbody = document.getElementById('transactionsBody');
    tbody.innerHTML = '';
    
    transactionData.transactions.forEach(transaction => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${transaction.id}</td>
            <td>${transaction.title}</td>
            <td>${transaction.description}</td>
            <td>$${transaction.price}</td>
            <td>${transaction.category}</td>
            <td>${transaction.sold ? 'Yes' : 'No'}</td>
        `;
        tbody.appendChild(row);
    });
}

function updateCharts(barData, pieData) {
    // Update Bar Chart
    if (barChart) {
        barChart.destroy();
    }
    
    const barCtx = document.getElementById('barChart').getContext('2d');
    barChart = new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: barData.map(item => item.range),
            datasets: [{
                label: 'Number of Items',
                data: barData.map(item => item.count),
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    
    // Update Pie Chart
    if (pieChart) {
        pieChart.destroy();
    }
    
    const pieCtx = document.getElementById('pieChart').getContext('2d');
    pieChart = new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: pieData.map(item => item.category),
            datasets: [{
                data: pieData.map(item => item.count),
                backgroundColor: [
                    '#FF6384',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF'
                ]
            }]
        }
    });
}

function updatePaginationControls() {
    document.getElementById('prevBtn').disabled = currentPage === 1;
    document.getElementById('nextBtn').disabled = currentPage === totalPages;
    document.getElementById('pageInfo').textContent = `Page ${currentPage} of ${totalPages}`;
}

// Event Listeners
document.getElementById('monthSelect').addEventListener('change', () => {
    currentPage = 1;
    fetchData();
});

document.getElementById('searchInput').addEventListener('input', debounce(() => {
    currentPage = 1;
    fetchData();
}, 300));

document.getElementById('prevBtn').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        fetchData();
    }
});

document.getElementById('nextBtn').addEventListener('click', () => {
    if (currentPage < totalPages) {
        currentPage++;
        fetchData();
    }
});

// Debounce function to limit API calls while typing
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
          };
          clearTimeout(timeout);
          timeout = setTimeout(later, wait);
      };
  }
  
  // Initial load
  document.addEventListener('DOMContentLoaded', fetchData);